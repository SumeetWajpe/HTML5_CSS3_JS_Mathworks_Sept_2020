            'use strict';
          var x = 10;
          x = "Hello";
          //y = 2000;

          function Test(){
            var l = 1000;
            console.log(l)              
          }
          