function GetDataUsingCallBack(url,callbackfunc){
    var xmlHttp = new XMLHttpRequest();
xmlHttp.open('GET',url);
xmlHttp.onreadystatechange = function(){
    // check for a condition if response is received
    if(xmlHttp.readyState == 4 && xmlHttp.status == 200){
        // get the data !
      callbackfunc(JSON.parse(xmlHttp.responseText));
    }
}
xmlHttp.send(); // actually makes the request !
}
