onmessage = function (msgFromMain){
    console.log('Within Worker Thread !',msgFromMain.data);
    console.log(new XMLHttpRequest()); // used for AJAX !   
    var largeArray = [];
            for (var i = 0; i < 5000; i++) {
                largeArray[i] = [];
                for (var j = 0; j < 7000; j++) {
                    largeArray[i][j] = Math.random();
                }
            }
 
    postMessage(largeArray[1000][2000]);
}